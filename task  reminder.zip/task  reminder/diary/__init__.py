__version__ = '0.3.4'
default_app_config = 'diary.apps.YourAppConfig'
