from django.apps import AppConfig

class YourAppConfig(AppConfig):
    name = 'diary'
    verbose_name = 'Master'
