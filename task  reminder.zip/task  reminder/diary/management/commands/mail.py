python ./manage.py email_reminder
